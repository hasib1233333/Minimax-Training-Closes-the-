"""
Reviewer-requested control: HBA-only optimization as a full main-study arm
(both optimizers, all 3 topologies, 8 seeds each) to separate the benefit of
"include betweenness attack" from the benefit of "minimax over a portfolio".
Uses the exact same (topology, seed) instances as results.csv -- same G0/H0
generation process -- so this is directly paired with the original data.

Iteration/episode counts are matched to the STATIC (single-attack) arm
(300 SA iterations, 200 RL episodes), since HBA-only is a single-attack
objective like HDA-only, not a portfolio objective -- this is the resource
control explicitly requested by the review, stated here rather than left
implicit.
"""
import sys, os, time, csv
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np

from graph_env import make_initial_graph, random_deletion_stage
from train import train_defender
from baselines import sa_baseline
from evaluate import evaluate_network

N = 50
BUDGET = 15
ALPHA = 0.3
TOPOLOGIES = ['BA', 'ER', 'WS']
SEEDS = list(range(1, 9))
RL_EPISODES = 200
SA_ITERS = 300

import sys as _sys
if len(_sys.argv) >= 4:
    TOPOLOGIES = [_sys.argv[1]]
    SEEDS = list(range(int(_sys.argv[2]), int(_sys.argv[3]) + 1))

OUT_CSV = os.path.join(os.path.dirname(__file__), '..', 'results', 'results_hba_arm.csv')
FIELDNAMES = ['method', 'topology', 'seed', 'objective_value', 'wall_time',
              'R_hda', 'R_hba', 'R_random', 'R_worst', 'worst_attack',
              'efficiency', 'alg_connectivity', 'adaptive_degradation_gap', 'n_edges']


def write_row(writer, f, row):
    writer.writerow(row)
    f.flush()


def run_all():
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    file_exists = os.path.exists(OUT_CSV)
    done = set()
    if file_exists:
        with open(OUT_CSV, 'r') as f:
            for row in csv.DictReader(f):
                done.add((row['method'], row['topology'], row['seed']))

    f = open(OUT_CSV, 'a', newline='')
    writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
    if not file_exists:
        writer.writeheader()
        f.flush()

    total_start = time.time()
    for topo in TOPOLOGIES:
        for seed in SEEDS:
            print(f"\n=== {topo} seed={seed} ===", flush=True)
            rng = np.random.default_rng(seed)
            G0 = make_initial_graph(topo, N, seed=seed)
            H0, _ = random_deletion_stage(G0, ALPHA, rng)

            key = ('SA-HBA', topo, str(seed))
            if key not in done:
                t0 = time.time()
                H, val = sa_baseline(H0, BUDGET, mode='hba', n_iters=SA_ITERS, seed=seed)
                metrics = evaluate_network(H)
                row = dict(method='SA-HBA', topology=topo, seed=seed,
                           objective_value=val, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('SA-HBA', val, f'({time.time()-t0:.1f}s)', flush=True)

            key = ('RL-HBA', topo, str(seed))
            if key not in done:
                t0 = time.time()
                out = train_defender(topo, N, seed, BUDGET, RL_EPISODES,
                                      alpha=ALPHA, reward_mode='hba', verbose=False)
                model, curve, elapsed, G0b, node_list_b, H0b, best_H, best_R = out
                metrics = evaluate_network(best_H)
                row = dict(method='RL-HBA', topology=topo, seed=seed,
                           objective_value=best_R, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('RL-HBA', best_R, f'({elapsed:.1f}s)', flush=True)

            print(f'--- {topo} seed={seed} total elapsed: {time.time()-total_start:.1f}s ---', flush=True)

    f.close()
    print(f"\nALL DONE. Total time: {time.time()-total_start:.1f}s")


if __name__ == '__main__':
    run_all()
