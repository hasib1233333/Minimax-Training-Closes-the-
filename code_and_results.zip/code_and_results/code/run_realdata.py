"""
Real-world validation on the US Western States Power Grid (Watts & Strogatz
1998; N=4941, E=6594; obtained from the Critical-Infrastructure-Networks
data repository, MIT license). Since the full network is far larger than
the synthetic study and betweenness/eigenvector recomputation does not
scale to N~5000 within our compute budget, we validate on connected
subgraphs of matched scale (N=50) sampled via breadth-first search from
random seed nodes -- a standard technique for computationally-bounded
study of large real networks. Each BFS sample is a genuine, topologically
contiguous fragment of real infrastructure (not synthetic), preserving its
local degree heterogeneity and clustering.

This script also uses the EXPANDED 6-attack evaluation portfolio
(HDA, HBA, Random, PageRank, Eigenvector, k-shell) to test whether minimax
training against the original 3-attack portfolio generalizes to attacks
never seen during training.
"""
import sys, os, time, csv
sys.path.insert(0, os.path.dirname(__file__))
import random
import numpy as np
import networkx as nx

from graph_env import random_deletion_stage
from train import train_defender
from baselines import random_baseline, dcbo_baseline, sa_baseline
from evaluate import evaluate_network

N_SUB = 50
BUDGET = 15
ALPHA = 0.3
N_SAMPLES = 6
RL_EPISODES = 200
SA_ITERS_STATIC = 300
SA_ITERS_MINIMAX = 250

EDGELIST_PATH = os.path.join(os.path.dirname(__file__), '..', 'realdata', 'powergridUSWS.csv')
OUT_CSV = os.path.join(os.path.dirname(__file__), '..', 'results', 'results_realdata.csv')
FIELDNAMES = ['method', 'sample_seed', 'objective_value', 'wall_time',
              'R_hda', 'R_hba', 'R_random', 'R_worst', 'worst_attack',
              'R_pagerank', 'R_eigenvector', 'R_kshell', 'R_worst6', 'worst_attack6', 'gap6',
              'efficiency', 'alg_connectivity', 'adaptive_degradation_gap', 'n_edges']


def bfs_sample(G_full, n_nodes, seed):
    rng = random.Random(seed)
    start = rng.choice(list(G_full.nodes()))
    visited = [start]
    frontier = [start]
    seen = {start}
    while len(visited) < n_nodes and frontier:
        u = frontier.pop(0)
        neighbors = list(G_full.neighbors(u))
        rng.shuffle(neighbors)
        for v in neighbors:
            if v not in seen:
                seen.add(v)
                visited.append(v)
                frontier.append(v)
                if len(visited) >= n_nodes:
                    break
    sub = G_full.subgraph(visited).copy()
    sub = nx.convert_node_labels_to_integers(sub)
    # ensure connected (BFS guarantees this by construction)
    assert nx.is_connected(sub), "BFS sample should be connected by construction"
    return sub


def run_all():
    G_full = nx.read_edgelist(EDGELIST_PATH, delimiter=',', nodetype=int)
    print(f"Loaded power grid: N={G_full.number_of_nodes()}, E={G_full.number_of_edges()}")

    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    file_exists = os.path.exists(OUT_CSV)
    done = set()
    if file_exists:
        with open(OUT_CSV, 'r') as f:
            for row in csv.DictReader(f):
                done.add((row['method'], row['sample_seed']))

    f = open(OUT_CSV, 'a', newline='')
    writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
    if not file_exists:
        writer.writeheader()
        f.flush()

    import sys as _s
    seeds_arg = list(range(1, N_SAMPLES + 1))
    if len(_s.argv) >= 3:
        seeds_arg = list(range(int(_s.argv[1]), int(_s.argv[2]) + 1))

    for seed in seeds_arg:
        print(f"\n=== power-grid sample seed={seed} ===", flush=True)
        G0 = bfs_sample(G_full, N_SUB, seed)
        node_list = list(G0.nodes())
        avg_deg = 2 * G0.number_of_edges() / G0.number_of_nodes()
        print(f"sample N={G0.number_of_nodes()} E={G0.number_of_edges()} avg_deg={avg_deg:.2f}", flush=True)
        rng = np.random.default_rng(seed)
        H0, _ = random_deletion_stage(G0, ALPHA, rng)

        def do(method_name, fn):
            key = (method_name, str(seed))
            if key in done:
                return
            t0 = time.time()
            H, val = fn()
            metrics = evaluate_network(H, expanded=True)
            row = dict(method=method_name, sample_seed=seed, objective_value=val,
                       wall_time=time.time() - t0, **metrics)
            writer.writerow(row)
            f.flush()
            print(method_name, val, f"({time.time()-t0:.1f}s)", flush=True)

        do('NoDesign', lambda: (H0, evaluate_network(H0)['R_hda']))
        do('Random', lambda: random_baseline(H0, BUDGET, 30, seed))
        do('DCBO', lambda: dcbo_baseline(H0, BUDGET))
        do('SA-Static', lambda: sa_baseline(H0, BUDGET, 'static', SA_ITERS_STATIC, seed))
        do('SA-Minimax', lambda: sa_baseline(H0, BUDGET, 'minimax', SA_ITERS_MINIMAX, seed))

        def rl_static():
            out = train_defender('BA', N_SUB, seed, BUDGET, RL_EPISODES, alpha=ALPHA,
                                  reward_mode='static', verbose=False)
            # override G0/H0 with the real-data instance instead of a synthetic one
            return _rl_on_instance(G0, H0, node_list, seed, 'static')

        def rl_minimax():
            return _rl_on_instance(G0, H0, node_list, seed, 'minimax')

        do('RL-Static', rl_static)
        do('RL-Minimax', rl_minimax)

    f.close()
    print("DONE")


def _rl_on_instance(G0, H0, node_list, seed, reward_mode):
    """Run the same A2C training loop as train.train_defender but on a
    pre-supplied (real-data) instance rather than a synthetically generated one."""
    import torch
    import torch.nn.functional as F
    from policy import ActorCritic, graph_to_tensors
    from graph_env import robustness_R, worst_case_R

    torch.manual_seed(seed)
    np.random.seed(seed)
    model = ActorCritic(in_dim=4, hid=24, emb=24)
    opt = torch.optim.Adam(model.parameters(), lr=3e-3)
    best_R, best_H = -1.0, None

    for ep in range(200):
        H = H0.copy()
        log_probs, values, rewards, entropies = [], [], [], []
        if reward_mode == 'static':
            r_prev = robustness_R(H, 'hda', recalculate=True)
        else:
            r_prev, _, _ = worst_case_R(H)
        for step in range(15):
            X, A_norm, pair_index, legal_pairs = graph_to_tensors(H, node_list)
            if pair_index.shape[0] == 0:
                break
            logits, value = model(X, A_norm, pair_index)
            probs = F.softmax(logits, dim=-1)
            dist = torch.distributions.Categorical(probs=probs)
            a = dist.sample()
            u, v = legal_pairs[a.item()]
            H.add_edge(u, v)
            if reward_mode == 'static':
                r_new = robustness_R(H, 'hda', recalculate=True)
            else:
                r_new, _, _ = worst_case_R(H)
            reward = r_new - r_prev
            r_prev = r_new
            log_probs.append(dist.log_prob(a))
            values.append(value)
            rewards.append(reward)
            entropies.append(dist.entropy())
        if not rewards:
            continue
        returns, R = [], 0.0
        for r in reversed(rewards):
            R = r + 0.98 * R
            returns.insert(0, R)
        returns = torch.tensor(returns, dtype=torch.float32)
        values_t = torch.stack(values)
        log_probs_t = torch.stack(log_probs)
        entropies_t = torch.stack(entropies)
        advantages = returns - values_t.detach()
        if advantages.numel() > 1:
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-6)
        loss = -(log_probs_t * advantages).mean() + 0.5 * F.mse_loss(values_t, returns) - 0.02 * entropies_t.mean()
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if r_prev > best_R:
            best_R, best_H = r_prev, H.copy()

    return best_H, best_R


if __name__ == '__main__':
    run_all()
