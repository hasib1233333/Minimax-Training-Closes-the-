"""
Common evaluation protocol applied identically to every method's final
designed network, so comparisons are fair regardless of what each method
was optimized for.
"""

from graph_env import robustness_R, worst_case_R, network_efficiency, algebraic_connectivity


TRAIN_PORTFOLIO = ('hda', 'hba', 'random')
EXPANDED_PORTFOLIO = ('hda', 'hba', 'random', 'pagerank', 'eigenvector', 'kshell')


def evaluate_network(H, expanded=False):
    r_hda = robustness_R(H, 'hda', recalculate=True)
    r_hba = robustness_R(H, 'hba', recalculate=True)
    r_rand = robustness_R(H, 'random', n_random_trials=15)
    r_worst, worst_attack, _ = worst_case_R(H, portfolio=TRAIN_PORTFOLIO)
    eff = network_efficiency(H)
    alg_conn = algebraic_connectivity(H)
    gap = r_hda - r_worst
    out = {
        'R_hda': r_hda,
        'R_hba': r_hba,
        'R_random': r_rand,
        'R_worst': r_worst,
        'worst_attack': worst_attack,
        'efficiency': eff,
        'alg_connectivity': alg_conn,
        'adaptive_degradation_gap': gap,
        'n_edges': H.number_of_edges(),
    }
    if expanded:
        r_pr = robustness_R(H, 'pagerank', recalculate=True)
        r_ev = robustness_R(H, 'eigenvector', recalculate=True)
        r_ks = robustness_R(H, 'kshell', recalculate=True)
        r_worst6, worst_attack6, _ = worst_case_R(H, portfolio=EXPANDED_PORTFOLIO)
        out.update({
            'R_pagerank': r_pr,
            'R_eigenvector': r_ev,
            'R_kshell': r_ks,
            'R_worst6': r_worst6,
            'worst_attack6': worst_attack6,
            'gap6': r_hda - r_worst6,
        })
    return out
