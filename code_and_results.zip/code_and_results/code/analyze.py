import pandas as pd
import numpy as np
from scipy.stats import wilcoxon

pd.set_option('display.width', 140)
pd.set_option('display.max_columns', 20)

df = pd.read_csv('/home/claude/netrob/results/results.csv')

METHOD_ORDER = ['NoDesign', 'Random', 'DCBO', 'SA-Static', 'SA-Minimax', 'RL-Static', 'RL-Minimax']

print("=" * 100)
print("TABLE 1: Mean (std) across 8 seeds, per method, pooled over all 3 topologies (n=24 each)")
print("=" * 100)
summary = df.groupby('method').agg(
    R_hda=('R_hda', lambda x: f"{x.mean():.4f} ({x.std():.4f})"),
    R_hba=('R_hba', lambda x: f"{x.mean():.4f} ({x.std():.4f})"),
    R_worst=('R_worst', lambda x: f"{x.mean():.4f} ({x.std():.4f})"),
    efficiency=('efficiency', lambda x: f"{x.mean():.4f}"),
    alg_conn=('alg_connectivity', lambda x: f"{x.mean():.4f}"),
    gap=('adaptive_degradation_gap', lambda x: f"{x.mean():.4f} ({x.std():.4f})"),
).reindex(METHOD_ORDER)
print(summary.to_string())

print()
print("=" * 100)
print("TABLE 2: Adaptive Degradation Gap (R_hda - R_worst) per method PER TOPOLOGY")
print("Lower gap = more uniformly robust / less brittle to attacker adaptation")
print("=" * 100)
gap_table = df.pivot_table(index='method', columns='topology', values='adaptive_degradation_gap',
                            aggfunc=['mean', 'std']).reindex(METHOD_ORDER)
print(gap_table.to_string())

print()
print("=" * 100)
print("TABLE 3: R_worst (worst-of-portfolio robustness) per method PER TOPOLOGY")
print("=" * 100)
rworst_table = df.pivot_table(index='method', columns='topology', values='R_worst',
                               aggfunc=['mean', 'std']).reindex(METHOD_ORDER)
print(rworst_table.to_string())

print()
print("=" * 100)
print("WILCOXON SIGNED-RANK TESTS (paired across 24 seed-topology instances)")
print("=" * 100)


def paired_wilcoxon(metric, m1, m2, label):
    a = df[df.method == m1].sort_values(['topology', 'seed'])[metric].values
    b = df[df.method == m2].sort_values(['topology', 'seed'])[metric].values
    assert len(a) == len(b) == 24
    diff = a - b
    try:
        stat, p = wilcoxon(a, b)
    except ValueError as e:
        stat, p = np.nan, np.nan
    print(f"{label:55s} mean_diff({m1}-{m2})={diff.mean():+.4f}  W={stat}  p={p:.4f}")


print("\n-- Hypothesis 1: does RL-Minimax show a SMALLER adaptive degradation gap than RL-Static? --")
paired_wilcoxon('adaptive_degradation_gap', 'RL-Static', 'RL-Minimax', 'Gap: RL-Static vs RL-Minimax')
paired_wilcoxon('adaptive_degradation_gap', 'SA-Static', 'SA-Minimax', 'Gap: SA-Static vs SA-Minimax')

print("\n-- Hypothesis 2: minimax-trained methods vs static-trained methods on R_worst --")
paired_wilcoxon('R_worst', 'RL-Minimax', 'RL-Static', 'R_worst: RL-Minimax vs RL-Static')
paired_wilcoxon('R_worst', 'SA-Minimax', 'SA-Static', 'R_worst: SA-Minimax vs SA-Static')

print("\n-- Hypothesis 3: RL-Minimax vs SA-Minimax (same objective, different optimizer) --")
paired_wilcoxon('R_worst', 'RL-Minimax', 'SA-Minimax', 'R_worst: RL-Minimax vs SA-Minimax')
paired_wilcoxon('adaptive_degradation_gap', 'RL-Minimax', 'SA-Minimax', 'Gap: RL-Minimax vs SA-Minimax')

print("\n-- Sanity: RL-Static vs SA-Static and DCBO on R_hda (single-attack objective) --")
paired_wilcoxon('R_hda', 'RL-Static', 'SA-Static', 'R_hda: RL-Static vs SA-Static')
paired_wilcoxon('R_hda', 'RL-Static', 'DCBO', 'R_hda: RL-Static vs DCBO')

print()
print("=" * 100)
print("Which attack is 'worst' most often, per method (shows brittleness profile)")
print("=" * 100)
print(df.pivot_table(index='method', columns='worst_attack', values='seed', aggfunc='count',
                      fill_value=0).reindex(METHOD_ORDER))

df.to_pickle('/home/claude/netrob/results/results_cache.pkl')
print("\nSaved cache.")
