"""
Classical (non-RL) baseline strategies for the edge-addition stage, all
operating on the SAME fixed damaged instance H0 with the SAME edge budget,
for a fair comparison against the RL methods.

  - random_baseline : adds `budget` random legal edges (best-of-K restarts)
  - dcbo_baseline    : greedy degree-variance reduction (Alenazi et al. 2014)
  - sa_baseline      : simulated annealing directly optimizing an objective
                       function (Buesser et al. 2011 / Schneider et al. 2011 style)
"""

import random
import math
import numpy as np

from graph_env import robustness_R, worst_case_R


def _objective(H, mode, portfolio=None):
    if mode == 'static':
        return robustness_R(H, 'hda', recalculate=True)
    else:
        r, _, _ = worst_case_R(H, portfolio=portfolio or ('hda', 'hba', 'random'))
        return r


def random_baseline(H0, budget, n_restarts, seed):
    rng = random.Random(seed)
    best_H, best_val = None, -1.0
    for _ in range(n_restarts):
        H = H0.copy()
        nodes = list(H.nodes())
        added = 0
        tries = 0
        while added < budget and tries < budget * 50:
            u, v = rng.sample(nodes, 2)
            tries += 1
            if not H.has_edge(u, v):
                H.add_edge(u, v)
                added += 1
        val = robustness_R(H, 'hda', recalculate=True)
        if val > best_val:
            best_val, best_H = val, H
    return best_H, best_val


def dcbo_baseline(H0, budget):
    """Degree-Centrality-Based Optimization: greedily connect the two
    lowest-degree, not-already-connected nodes at each step (reduces degree
    variance, the classical homogeneous-design heuristic)."""
    H = H0.copy()
    for _ in range(budget):
        nodes = sorted(H.nodes(), key=lambda n: H.degree(n))
        added = False
        for i in range(len(nodes)):
            for j in range(i + 1, min(i + 6, len(nodes))):  # small local search window
                u, v = nodes[i], nodes[j]
                if not H.has_edge(u, v):
                    H.add_edge(u, v)
                    added = True
                    break
            if added:
                break
        if not added:
            # fallback: connect two lowest-degree nodes regardless of proximity in list
            for i in range(len(nodes)):
                for j in range(i + 1, len(nodes)):
                    u, v = nodes[i], nodes[j]
                    if not H.has_edge(u, v):
                        H.add_edge(u, v)
                        added = True
                        break
                if added:
                    break
        if not added:
            break
    val = robustness_R(H, 'hda', recalculate=True)
    return H, val


def sa_baseline(H0, budget, mode, n_iters, seed, T0=0.05, cooling=0.995, portfolio=None):
    """Simulated annealing: start from H0 + `budget` random legal edges (to
    match edge count with other methods), then repeatedly propose swapping
    one added edge for another legal one, accepting via Metropolis criterion.
    Objective = R_hda (mode='static') or worst-of-portfolio (mode='minimax').
    """
    rng = random.Random(seed)
    H = H0.copy()
    nodes = list(H.nodes())
    added_edges = []
    tries = 0
    while len(added_edges) < budget and tries < budget * 50:
        u, v = rng.sample(nodes, 2)
        tries += 1
        if not H.has_edge(u, v):
            H.add_edge(u, v)
            added_edges.append((u, v))

    cur_val = _objective(H, mode, portfolio)
    best_H, best_val = H.copy(), cur_val
    T = T0

    for it in range(n_iters):
        if not added_edges:
            break
        # propose: remove one added edge, add a different random legal edge
        idx = rng.randrange(len(added_edges))
        old_edge = added_edges[idx]
        if H.has_edge(*old_edge):
            H.remove_edge(*old_edge)

        # find a new legal edge
        new_edge = None
        for _ in range(20):
            u, v = rng.sample(nodes, 2)
            if not H.has_edge(u, v):
                new_edge = (u, v)
                break
        if new_edge is None:
            H.add_edge(*old_edge)
            continue
        H.add_edge(*new_edge)

        new_val = _objective(H, mode, portfolio)
        delta = new_val - cur_val
        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-6)):
            cur_val = new_val
            added_edges[idx] = new_edge
            if cur_val > best_val:
                best_val, best_H = cur_val, H.copy()
        else:
            # reject: revert
            H.remove_edge(*new_edge)
            H.add_edge(*old_edge)

        T *= cooling

    return best_H, best_val
