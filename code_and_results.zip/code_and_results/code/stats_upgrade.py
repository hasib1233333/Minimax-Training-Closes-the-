import pandas as pd
import numpy as np
from scipy.stats import wilcoxon

rng = np.random.default_rng(0)
df = pd.read_pickle('/home/claude/netrob/results/results_cache.pkl')


def rank_biserial(a, b):
    """Matched-pairs rank-biserial correlation effect size for Wilcoxon
    signed-rank test. r in [-1,1]; |r|>=0.5 large, ~0.3 medium, ~0.1 small."""
    diff = a - b
    diff = diff[diff != 0]
    n = len(diff)
    if n == 0:
        return 0.0
    ranks = pd.Series(np.abs(diff)).rank().values
    pos = ranks[diff > 0].sum()
    neg = ranks[diff < 0].sum()
    return (pos - neg) / (n * (n + 1) / 2)


def bootstrap_ci(diff, n_boot=10000, alpha=0.05):
    boots = np.array([np.mean(rng.choice(diff, size=len(diff), replace=True)) for _ in range(n_boot)])
    lo, hi = np.percentile(boots, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return lo, hi


def paired_test(metric, m1, m2):
    a = df[df.method == m1].sort_values(['topology', 'seed'])[metric].values
    b = df[df.method == m2].sort_values(['topology', 'seed'])[metric].values
    diff = a - b
    stat, p = wilcoxon(a, b)
    r = rank_biserial(a, b)
    lo, hi = bootstrap_ci(diff)
    return dict(comparison=f"{m1} vs {m2}", metric=metric, mean_diff=diff.mean(),
                ci_lo=lo, ci_hi=hi, wilcoxon_W=stat, p_raw=p, rank_biserial_r=r)


tests = [
    paired_test('adaptive_degradation_gap', 'RL-Static', 'RL-Minimax'),
    paired_test('adaptive_degradation_gap', 'SA-Static', 'SA-Minimax'),
    paired_test('R_worst', 'RL-Minimax', 'RL-Static'),
    paired_test('R_worst', 'SA-Minimax', 'SA-Static'),
    paired_test('R_worst', 'RL-Minimax', 'SA-Minimax'),
    paired_test('adaptive_degradation_gap', 'RL-Minimax', 'SA-Minimax'),
    paired_test('R_hda', 'RL-Static', 'SA-Static'),
    paired_test('R_hda', 'RL-Static', 'DCBO'),
]

res = pd.DataFrame(tests)

# Holm-Bonferroni correction across the family of 8 tests
order = res['p_raw'].argsort()
m = len(res)
p_sorted = res['p_raw'].values[order]
holm_adj = np.empty(m)
running_max = 0.0
for i, p in enumerate(p_sorted):
    val = min((m - i) * p, 1.0)
    running_max = max(running_max, val)
    holm_adj[i] = running_max
res_sorted = res.iloc[order].copy()
res_sorted['p_holm'] = holm_adj
res_sorted = res_sorted.sort_index()

pd.set_option('display.width', 160)
pd.set_option('display.max_columns', 20)
print(res_sorted[['comparison', 'metric', 'mean_diff', 'ci_lo', 'ci_hi',
                   'rank_biserial_r', 'p_raw', 'p_holm']].to_string(index=False))

res_sorted.to_csv('/home/claude/netrob/results/stats_full.csv', index=False)
print("\nsaved stats_full.csv")
