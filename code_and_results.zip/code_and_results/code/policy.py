"""
Lightweight GCN-based actor-critic policy for the edge-addition rewiring task.

Architecture (deliberately small, CPU-feasible):
  - 2-layer GCN encoder producing per-node embeddings
  - Actor: scores all legal non-edges via a bilinear+MLP head, softmax -> sample
  - Critic: mean-pooled graph embedding -> scalar value

This mirrors the spirit of GNN-based robustness-design actors in the literature
(e.g. GATv2 encoders in Zhu et al. 2026) but is intentionally shallow / small
for tractability on CPU within a modest compute budget.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from graph_env import node_features, adjacency_matrix, legal_additions_mask


class GCNLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.lin = nn.Linear(in_dim, out_dim)

    def forward(self, X, A_norm):
        # A_norm: (N,N) normalized adjacency (with self loops), X: (N,F)
        return F.relu(self.lin(A_norm @ X))


class Encoder(nn.Module):
    def __init__(self, in_dim=4, hid=24, out_dim=24):
        super().__init__()
        self.g1 = GCNLayer(in_dim, hid)
        self.g2 = GCNLayer(hid, out_dim)

    def forward(self, X, A_norm):
        h = self.g1(X, A_norm)
        h = self.g2(h, A_norm)
        return h  # (N, out_dim)


class ActorCritic(nn.Module):
    def __init__(self, in_dim=4, hid=24, emb=24):
        super().__init__()
        self.encoder = Encoder(in_dim, hid, emb)
        self.edge_head = nn.Sequential(
            nn.Linear(emb * 2, hid), nn.ReLU(), nn.Linear(hid, 1)
        )
        self.value_head = nn.Sequential(
            nn.Linear(emb, hid), nn.ReLU(), nn.Linear(hid, 1)
        )

    def forward(self, X, A_norm, pair_index):
        """pair_index: (M,2) long tensor of legal non-edge node indices."""
        z = self.encoder(X, A_norm)  # (N, emb)
        zu = z[pair_index[:, 0]]
        zv = z[pair_index[:, 1]]
        pair_repr = torch.cat([zu * zv, torch.abs(zu - zv)], dim=-1)
        logits = self.edge_head(pair_repr).squeeze(-1)  # (M,)
        graph_emb = z.mean(dim=0)
        value = self.value_head(graph_emb).squeeze(-1)
        return logits, value


def normalized_adjacency(A):
    N = A.shape[0]
    A_hat = A + np.eye(N, dtype=np.float32)
    deg = A_hat.sum(axis=1)
    d_inv_sqrt = np.zeros_like(deg)
    np.power(deg, -0.5, where=deg > 0, out=d_inv_sqrt)
    D_inv_sqrt = np.diag(d_inv_sqrt).astype(np.float32)
    return D_inv_sqrt @ A_hat @ D_inv_sqrt


def graph_to_tensors(H, node_list):
    X = node_features(H, node_list)
    A = adjacency_matrix(H, node_list)
    A_norm = normalized_adjacency(A)
    mask, pair_list = legal_additions_mask(H, node_list)
    idx = {n: i for i, n in enumerate(node_list)}
    legal_pairs = [pair_list[k] for k in range(len(pair_list)) if mask[k]]
    pair_index = np.array([[idx[u], idx[v]] for u, v in legal_pairs], dtype=np.int64)
    return (torch.from_numpy(X), torch.from_numpy(A_norm),
            torch.from_numpy(pair_index), legal_pairs)
