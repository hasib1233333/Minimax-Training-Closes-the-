"""
Graph environment for network robustness rewiring.

Implements:
  - Schneider et al. (2011) robustness index R(G) under various attack strategies
  - Recalculated (adaptive-within-dismantling) HDA / HBA / Random attacks
  - A worst-of-portfolio "adaptive attacker" evaluator
  - The two-stage rewiring mechanic (random deletion + strategic addition),
    following the decomposition used in Zhu et al., Nat. Commun. 2026.
  - Node structural feature extraction for the GNN policy.
"""

import networkx as nx
import numpy as np
import random


# ----------------------------- Robustness metric -----------------------------

def robustness_R(G, attack='hda', recalculate=True, n_random_trials=10, rng=None):
    """
    Schneider robustness index:
        R(G) = (1/N) * sum_{Q=0}^{N-1} s(Q)
    where s(Q) is the fraction of nodes in the largest connected component
    after removing the top-Q nodes under the given attack ordering.

    attack: 'hda' (high degree), 'hba' (high betweenness), 'random'
    recalculate: if True, ranking is recomputed after each removal (adaptive
                 dismantling); if False, ranking is fixed at G's initial state.
    """
    if attack == 'random':
        rng = rng or random.Random()
        vals = []
        for _ in range(n_random_trials):
            vals.append(_robustness_single(G, 'random', recalculate, rng))
        return float(np.mean(vals))
    return _robustness_single(G, attack, recalculate, rng)


def _robustness_single(G, attack, recalculate, rng):
    N = G.number_of_nodes()
    if N <= 1:
        return 1.0
    H = G.copy()

    if attack == 'random':
        order = list(H.nodes())
        (rng or random).shuffle(order)
    elif not recalculate:
        order = _rank_nodes(H, attack)
    else:
        order = None  # computed on the fly

    s_vals = [1.0]  # Q=0: full network, s=1
    for q in range(N - 1):
        if attack == 'random':
            v = order[q]
        elif not recalculate:
            v = order[q]
        else:
            ranking = _rank_nodes(H, attack)
            v = ranking[0]
        if H.has_node(v):
            H.remove_node(v)
        if H.number_of_nodes() == 0:
            s_vals.append(0.0)
            continue
        largest_cc = max((len(c) for c in nx.connected_components(H)), default=0)
        s_vals.append(largest_cc / N)

    return float(np.mean(s_vals))


def _rank_nodes(H, attack):
    """Return nodes ranked highest-priority-to-remove first."""
    if attack == 'hda':
        deg = dict(H.degree())
        return sorted(deg, key=lambda n: deg[n], reverse=True)
    elif attack == 'hba':
        bc = nx.betweenness_centrality(H, normalized=True)
        return sorted(bc, key=lambda n: bc[n], reverse=True)
    elif attack == 'pagerank':
        pr = nx.pagerank(H, alpha=0.85)
        return sorted(pr, key=lambda n: pr[n], reverse=True)
    elif attack == 'eigenvector':
        if H.number_of_edges() == 0:
            return list(H.nodes())
        if nx.is_connected(H):
            try:
                ev = nx.eigenvector_centrality(H, max_iter=1000)
            except nx.PowerIterationFailedConvergence:
                ev = {n: H.degree(n) for n in H.nodes()}
        else:
            # compute per connected component, isolated/small components rank lowest
            ev = {}
            for comp in nx.connected_components(H):
                sub = H.subgraph(comp)
                if len(comp) < 3:
                    for n in comp:
                        ev[n] = 0.0
                    continue
                try:
                    ev_sub = nx.eigenvector_centrality(sub, max_iter=1000)
                except nx.PowerIterationFailedConvergence:
                    ev_sub = {n: sub.degree(n) for n in comp}
                ev.update(ev_sub)
        return sorted(ev, key=lambda n: ev[n], reverse=True)
    elif attack == 'kshell':
        core = nx.core_number(H)
        return sorted(core, key=lambda n: core[n], reverse=True)
    else:
        raise ValueError(attack)


def worst_case_R(G, portfolio=('hda', 'hba', 'random'), recalculate=True, rng=None):
    """Adaptive / minimax attacker: reports the MINIMUM robustness across a
    portfolio of attack strategies -- i.e. the attacker picks whichever
    known strategy is most damaging to this specific topology."""
    vals = {a: robustness_R(G, attack=a, recalculate=recalculate, rng=rng) for a in portfolio}
    worst_attack = min(vals, key=vals.get)
    return vals[worst_attack], worst_attack, vals


def network_efficiency(G):
    N = G.number_of_nodes()
    if N <= 1:
        return 0.0
    total = 0.0
    for comp in nx.connected_components(G):
        sub = G.subgraph(comp)
        if len(comp) <= 1:
            continue
        lengths = dict(nx.all_pairs_shortest_path_length(sub))
        for u in lengths:
            for v, d in lengths[u].items():
                if u != v and d > 0:
                    total += 1.0 / d
    return total / (N * (N - 1))


def algebraic_connectivity(G):
    if G.number_of_nodes() < 2 or not nx.is_connected(G):
        # use largest component
        comp = max(nx.connected_components(G), key=len)
        G = G.subgraph(comp)
    if G.number_of_nodes() < 3:
        return 0.0
    try:
        return float(nx.algebraic_connectivity(G, method='lanczos'))
    except Exception:
        return 0.0


# ----------------------------- Rewiring mechanics -----------------------------

def random_deletion_stage(G, alpha, rng):
    """Delete a fraction alpha of edges uniformly at random. Returns (H, n_deleted)."""
    H = G.copy()
    edges = list(H.edges())
    n_del = int(round(alpha * len(edges)))
    rng.shuffle(edges)
    for e in edges[:n_del]:
        if H.has_edge(*e):
            H.remove_edge(*e)
    return H, n_del


def legal_additions_mask(H, node_list):
    """Boolean mask over all N*(N-1)/2 unordered pairs: True if pair is a
    legal edge to add (not self loop, not already an edge)."""
    N = len(node_list)
    idx = {n: i for i, n in enumerate(node_list)}
    mask = np.ones(N * (N - 1) // 2, dtype=bool)
    k = 0
    pair_list = []
    for i in range(N):
        for j in range(i + 1, N):
            pair_list.append((node_list[i], node_list[j]))
    for k, (u, v) in enumerate(pair_list):
        if H.has_edge(u, v):
            mask[k] = False
    return mask, pair_list


# ----------------------------- Node features -----------------------------

def node_features(H, node_list):
    """Return an (N, F) feature matrix: degree, clustering, avg-neighbor-degree,
    2-hop reach, all min-max normalized."""
    N = len(node_list)
    deg = dict(H.degree())
    clus = nx.clustering(H)
    try:
        ann = nx.average_neighbor_degree(H)
    except Exception:
        ann = {n: 0.0 for n in node_list}
    try:
        kcore = nx.core_number(H)
    except Exception:
        kcore = {n: 0 for n in node_list}

    feats = np.zeros((N, 4), dtype=np.float32)
    for i, n in enumerate(node_list):
        feats[i, 0] = deg.get(n, 0)
        feats[i, 1] = clus.get(n, 0.0)
        feats[i, 2] = ann.get(n, 0.0)
        feats[i, 3] = kcore.get(n, 0)

    # min-max normalize each column
    for c in range(feats.shape[1]):
        col = feats[:, c]
        lo, hi = col.min(), col.max()
        if hi - lo > 1e-9:
            feats[:, c] = (col - lo) / (hi - lo)
        else:
            feats[:, c] = 0.0
    return feats


def adjacency_matrix(H, node_list):
    N = len(node_list)
    idx = {n: i for i, n in enumerate(node_list)}
    A = np.zeros((N, N), dtype=np.float32)
    for u, v in H.edges():
        A[idx[u], idx[v]] = 1.0
        A[idx[v], idx[u]] = 1.0
    return A


# ----------------------------- Generators -----------------------------

def make_initial_graph(kind, N, seed, avg_degree=4):
    rng = np.random.default_rng(seed)
    if kind == 'BA':
        m = max(1, avg_degree // 2)
        G = nx.barabasi_albert_graph(N, m, seed=seed)
    elif kind == 'ER':
        p = avg_degree / (N - 1)
        G = nx.erdos_renyi_graph(N, p, seed=seed)
        # ensure connected: attach isolated components
        G = _connect_components(G, seed)
    elif kind == 'WS':
        k = avg_degree if avg_degree % 2 == 0 else avg_degree + 1
        G = nx.watts_strogatz_graph(N, k, 0.1, seed=seed)
    else:
        raise ValueError(kind)
    return G


def _connect_components(G, seed):
    rng = random.Random(seed)
    comps = list(nx.connected_components(G))
    if len(comps) <= 1:
        return G
    comps = [list(c) for c in comps]
    for i in range(len(comps) - 1):
        u = rng.choice(comps[i])
        v = rng.choice(comps[i + 1])
        G.add_edge(u, v)
    return G
