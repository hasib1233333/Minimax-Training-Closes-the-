"""
Ablation: which attacks in the training portfolio actually matter?
Uses SA as the optimizer (justified by the main study's finding that RL and
SA are statistically indistinguishable given the same objective -- this
lets us cover 5 portfolio configurations x seeds cheaply). BA topology,
same N/alpha/budget as the main study. All configurations evaluated under
the fixed EXPANDED 6-attack portfolio for a common yardstick.
"""
import sys, os, csv, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np

from graph_env import make_initial_graph, random_deletion_stage
from baselines import sa_baseline
from evaluate import evaluate_network

N, BUDGET, ALPHA = 50, 15, 0.3
SEEDS = list(range(1, 6))  # 5 seeds
SA_ITERS = 250

CONFIGS = {
    'HDA-only':      ('hda',),
    'HBA-only':      ('hba',),
    'HDA+HBA':       ('hda', 'hba'),
    'HDA+Random':    ('hda', 'random'),
    'HDA+HBA+Random (full)': ('hda', 'hba', 'random'),
}

OUT_CSV = os.path.join(os.path.dirname(__file__), '..', 'results', 'results_ablation.csv')
FIELDNAMES = ['config', 'seed', 'objective_value', 'wall_time',
              'R_hda', 'R_hba', 'R_random', 'R_worst', 'worst_attack',
              'R_pagerank', 'R_eigenvector', 'R_kshell', 'R_worst6', 'worst_attack6', 'gap6',
              'efficiency', 'alg_connectivity', 'adaptive_degradation_gap', 'n_edges']


def run_all():
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    file_exists = os.path.exists(OUT_CSV)
    done = set()
    if file_exists:
        with open(OUT_CSV, 'r') as f:
            for row in csv.DictReader(f):
                done.add((row['config'], row['seed']))
    f = open(OUT_CSV, 'a', newline='')
    writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
    if not file_exists:
        writer.writeheader()
        f.flush()

    for seed in SEEDS:
        rng = np.random.default_rng(seed)
        G0 = make_initial_graph('BA', N, seed=seed)
        H0, _ = random_deletion_stage(G0, ALPHA, rng)
        for name, portfolio in CONFIGS.items():
            key = (name, str(seed))
            if key in done:
                continue
            t0 = time.time()
            mode = 'static' if portfolio == ('hda',) else 'minimax'
            H, val = sa_baseline(H0, BUDGET, mode, SA_ITERS, seed, portfolio=portfolio)
            metrics = evaluate_network(H, expanded=True)
            row = dict(config=name, seed=seed, objective_value=val,
                       wall_time=time.time() - t0, **metrics)
            writer.writerow(row)
            f.flush()
            print(f"seed={seed} config={name}: gap6={metrics['gap6']:.4f} R_worst6={metrics['R_worst6']:.4f} ({time.time()-t0:.1f}s)", flush=True)
    f.close()
    print("DONE")


if __name__ == '__main__':
    run_all()
