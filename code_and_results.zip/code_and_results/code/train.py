"""
Training loop for the defender (edge-addition) policy.

Two reward regimes:
  - 'static'  : reward = improvement in R under ONE fixed attack (HDA-recalc).
                Represents the standard paradigm in prior work
                (RNet-DQN, ResiNet, Zhu et al. 2026).
  - 'minimax' : reward = improvement in worst-of-portfolio R across
                {HDA-recalc, HBA-recalc, Random}. This is the novel
                co-adaptive / reconnaissance-aware training objective (ACT).

Algorithm: single-trajectory Advantage Actor-Critic (A2C) with entropy
regularization. Chosen over full PPO for implementation reliability within
the compute/time budget; this is a documented, deliberate scope choice.
"""

import time
import numpy as np
import torch
import torch.nn.functional as F

from graph_env import (make_initial_graph, random_deletion_stage,
                        robustness_R, worst_case_R)
from policy import ActorCritic, graph_to_tensors


def train_defender(kind, N, seed, budget, n_episodes, alpha=0.3,
                    reward_mode='static', lr=3e-3, entropy_coef=0.02,
                    gamma=0.98, log_every=50, verbose=True):
    """
    Instance-specific policy-gradient optimization: ONE damaged instance H0
    (fixed random deletion draw) is generated once, and the policy is
    optimized over many rollouts to find a strong rewiring FOR THAT INSTANCE.
    This mirrors how the SA / DCBO baselines also operate on a single fixed
    instance, keeping the comparison apples-to-apples, and removes the large
    variance source of resampling the damaged graph every episode.

    Returns: trained model, list of episode final-R (learning curve), elapsed time
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    rng = np.random.default_rng(seed)

    G0 = make_initial_graph(kind, N, seed=seed)
    node_list = list(G0.nodes())
    H0, _ = random_deletion_stage(G0, alpha, rng)  # FIXED damaged instance

    model = ActorCritic(in_dim=4, hid=24, emb=24)
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    curve = []
    t0 = time.time()
    best_R = -1.0
    best_H = None

    for ep in range(n_episodes):
        H = H0.copy()

        log_probs, values, rewards, entropies = [], [], [], []

        if reward_mode == 'static':
            r_prev = robustness_R(H, 'hda', recalculate=True)
        else:
            r_prev, _, _ = worst_case_R(H)

        for step in range(budget):
            X, A_norm, pair_index, legal_pairs = graph_to_tensors(H, node_list)
            if pair_index.shape[0] == 0:
                break
            logits, value = model(X, A_norm, pair_index)
            probs = F.softmax(logits, dim=-1)
            dist = torch.distributions.Categorical(probs=probs)
            a = dist.sample()
            log_prob = dist.log_prob(a)
            entropy = dist.entropy()

            u, v = legal_pairs[a.item()]
            H.add_edge(u, v)

            if reward_mode == 'static':
                r_new = robustness_R(H, 'hda', recalculate=True)
            else:
                r_new, _, _ = worst_case_R(H)
            reward = r_new - r_prev
            r_prev = r_new

            log_probs.append(log_prob)
            values.append(value)
            rewards.append(reward)
            entropies.append(entropy)

        # ---- A2C update with discounted returns ----
        if len(rewards) == 0:
            continue
        returns = []
        R = 0.0
        for r in reversed(rewards):
            R = r + gamma * R
            returns.insert(0, R)
        returns = torch.tensor(returns, dtype=torch.float32)
        values_t = torch.stack(values)
        log_probs_t = torch.stack(log_probs)
        entropies_t = torch.stack(entropies)

        advantages = returns - values_t.detach()
        if advantages.numel() > 1:
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-6)

        policy_loss = -(log_probs_t * advantages).mean()
        value_loss = F.mse_loss(values_t, returns)
        entropy_loss = -entropies_t.mean()
        loss = policy_loss + 0.5 * value_loss + entropy_coef * entropy_loss

        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        curve.append(r_prev)
        if r_prev > best_R:
            best_R = r_prev
            best_H = H.copy()
        if verbose and (ep + 1) % log_every == 0:
            print(f"  ep {ep+1}/{n_episodes}  R_final={r_prev:.4f}  best={best_R:.4f}  "
                  f"loss={loss.item():.4f}  elapsed={time.time()-t0:.1f}s")

    elapsed = time.time() - t0
    return model, curve, elapsed, G0, node_list, H0, best_H, best_R


def apply_trained_policy(model, H0, node_list, budget):
    """Deploy a trained policy deterministically (argmax) on the given
    (already-damaged) instance H0."""
    H = H0.copy()
    for step in range(budget):
        X, A_norm, pair_index, legal_pairs = graph_to_tensors(H, node_list)
        if pair_index.shape[0] == 0:
            break
        with torch.no_grad():
            logits, _ = model(X, A_norm, pair_index)
        a = int(torch.argmax(logits).item())
        u, v = legal_pairs[a]
        H.add_edge(u, v)
    return H
