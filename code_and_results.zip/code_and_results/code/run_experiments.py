"""
Full experiment grid: {NoDesign, Random, DCBO, SA-Static, SA-Minimax,
RL-Static, RL-Minimax(ACT)} x {BA, ER, WS} x {seeds 1..N_SEEDS}

Saves one row per (method, topology, seed) to results/results.csv,
flushing after every run so partial progress survives interruption.
"""

import sys, os, time, csv
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

from graph_env import make_initial_graph, random_deletion_stage, robustness_R
from train import train_defender, apply_trained_policy
from baselines import random_baseline, dcbo_baseline, sa_baseline
from evaluate import evaluate_network

# ---------------- config ----------------
N = 50
BUDGET = 15
ALPHA = 0.3
TOPOLOGIES = ['BA', 'ER', 'WS']
SEEDS = list(range(1, 9))          # 8 seeds per topology

# allow overriding via CLI: python run_experiments.py BA 1 4
import sys as _sys
if len(_sys.argv) >= 4:
    TOPOLOGIES = [_sys.argv[1]]
    SEEDS = list(range(int(_sys.argv[2]), int(_sys.argv[3]) + 1))
RL_EPISODES_STATIC = 200
RL_EPISODES_MINIMAX = 200
SA_ITERS_STATIC = 300
SA_ITERS_MINIMAX = 250
RANDOM_RESTARTS = 30

OUT_CSV = os.path.join(os.path.dirname(__file__), '..', 'results', 'results.csv')
FIELDNAMES = ['method', 'topology', 'seed', 'objective_value', 'wall_time',
              'R_hda', 'R_hba', 'R_random', 'R_worst', 'worst_attack',
              'efficiency', 'alg_connectivity', 'adaptive_degradation_gap', 'n_edges']


def write_row(writer, f, row):
    writer.writerow(row)
    f.flush()


def run_all():
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    file_exists = os.path.exists(OUT_CSV)
    done = set()
    if file_exists:
        with open(OUT_CSV, 'r') as f:
            for row in csv.DictReader(f):
                done.add((row['method'], row['topology'], row['seed']))

    f = open(OUT_CSV, 'a', newline='')
    writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
    if not file_exists:
        writer.writeheader()
        f.flush()

    total_start = time.time()
    for topo in TOPOLOGIES:
        for seed in SEEDS:
            print(f"\n=== {topo} seed={seed} ===", flush=True)
            rng = np.random.default_rng(seed)
            G0 = make_initial_graph(topo, N, seed=seed)
            node_list = list(G0.nodes())
            H0, _ = random_deletion_stage(G0, ALPHA, rng)

            # ---- NoDesign ----
            key = ('NoDesign', topo, str(seed))
            if key not in done:
                t0 = time.time()
                metrics = evaluate_network(H0)
                row = dict(method='NoDesign', topology=topo, seed=seed,
                           objective_value=metrics['R_hda'], wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('NoDesign', metrics['R_hda'], flush=True)

            # ---- Random ----
            key = ('Random', topo, str(seed))
            if key not in done:
                t0 = time.time()
                H, val = random_baseline(H0, BUDGET, RANDOM_RESTARTS, seed)
                metrics = evaluate_network(H)
                row = dict(method='Random', topology=topo, seed=seed,
                           objective_value=val, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('Random', val, flush=True)

            # ---- DCBO ----
            key = ('DCBO', topo, str(seed))
            if key not in done:
                t0 = time.time()
                H, val = dcbo_baseline(H0, BUDGET)
                metrics = evaluate_network(H)
                row = dict(method='DCBO', topology=topo, seed=seed,
                           objective_value=val, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('DCBO', val, flush=True)

            # ---- SA-Static ----
            key = ('SA-Static', topo, str(seed))
            if key not in done:
                t0 = time.time()
                H, val = sa_baseline(H0, BUDGET, mode='static', n_iters=SA_ITERS_STATIC, seed=seed)
                metrics = evaluate_network(H)
                row = dict(method='SA-Static', topology=topo, seed=seed,
                           objective_value=val, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('SA-Static', val, flush=True)

            # ---- SA-Minimax ----
            key = ('SA-Minimax', topo, str(seed))
            if key not in done:
                t0 = time.time()
                H, val = sa_baseline(H0, BUDGET, mode='minimax', n_iters=SA_ITERS_MINIMAX, seed=seed)
                metrics = evaluate_network(H)
                row = dict(method='SA-Minimax', topology=topo, seed=seed,
                           objective_value=val, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('SA-Minimax', val, flush=True)

            # ---- RL-Static ----
            key = ('RL-Static', topo, str(seed))
            if key not in done:
                t0 = time.time()
                out = train_defender(topo, N, seed, BUDGET, RL_EPISODES_STATIC,
                                      alpha=ALPHA, reward_mode='static', verbose=False)
                model, curve, elapsed, G0b, node_list_b, H0b, best_H, best_R = out
                metrics = evaluate_network(best_H)
                row = dict(method='RL-Static', topology=topo, seed=seed,
                           objective_value=best_R, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('RL-Static', best_R, f'({elapsed:.1f}s)', flush=True)

            # ---- RL-Minimax (ACT, novel method) ----
            key = ('RL-Minimax', topo, str(seed))
            if key not in done:
                t0 = time.time()
                out = train_defender(topo, N, seed, BUDGET, RL_EPISODES_MINIMAX,
                                      alpha=ALPHA, reward_mode='minimax', verbose=False)
                model, curve, elapsed, G0b, node_list_b, H0b, best_H, best_R = out
                metrics = evaluate_network(best_H)
                row = dict(method='RL-Minimax', topology=topo, seed=seed,
                           objective_value=best_R, wall_time=time.time() - t0, **metrics)
                write_row(writer, f, row)
                print('RL-Minimax', best_R, f'({elapsed:.1f}s)', flush=True)

            print(f'--- {topo} seed={seed} total elapsed: {time.time()-total_start:.1f}s ---', flush=True)

    f.close()
    print(f"\nALL DONE. Total time: {time.time()-total_start:.1f}s")


if __name__ == '__main__':
    run_all()
