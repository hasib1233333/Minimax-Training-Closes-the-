"""
Scale-up check: does the gap-reduction effect hold at 2x the main study's
scale (N=100), and how does wall-clock cost grow? Uses SA for the full
seed set (justified by optimizer-invariance finding) plus a small RL
spot-check (3 seeds) to confirm the learned policy still functions at this
scale. BA topology only, to keep this a focused robustness check rather
than a full second grid.
"""
import sys, os, csv, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np

from graph_env import make_initial_graph, random_deletion_stage
from baselines import sa_baseline, dcbo_baseline, random_baseline
from evaluate import evaluate_network
from train import train_defender

N, BUDGET, ALPHA = 100, 20, 0.3
SEEDS_SA = list(range(1, 6))
SEEDS_RL = [1, 2]
RL_EPISODES = 80

OUT_CSV = os.path.join(os.path.dirname(__file__), '..', 'results', 'results_scaleup.csv')
FIELDNAMES = ['method', 'seed', 'objective_value', 'wall_time',
              'R_hda', 'R_hba', 'R_worst', 'adaptive_degradation_gap', 'n_edges']


def run():
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    file_exists = os.path.exists(OUT_CSV)
    done = set()
    if file_exists:
        with open(OUT_CSV, 'r') as f:
            for row in csv.DictReader(f):
                done.add((row['method'], row['seed']))
    f = open(OUT_CSV, 'a', newline='')
    writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
    if not file_exists:
        writer.writeheader()
        f.flush()

    for seed in SEEDS_SA:
        rng = np.random.default_rng(seed)
        G0 = make_initial_graph('BA', N, seed=seed)
        H0, _ = random_deletion_stage(G0, ALPHA, rng)

        def do(name, fn):
            key = (name, str(seed))
            if key in done:
                return
            t0 = time.time()
            H, val = fn()
            m = evaluate_network(H)
            row = dict(method=name, seed=seed, objective_value=val, wall_time=time.time()-t0,
                       R_hda=m['R_hda'], R_hba=m['R_hba'], R_worst=m['R_worst'],
                       adaptive_degradation_gap=m['adaptive_degradation_gap'], n_edges=m['n_edges'])
            writer.writerow(row)
            f.flush()
            print(f"N=100 seed={seed} {name}: gap={m['adaptive_degradation_gap']:.4f} ({time.time()-t0:.1f}s)", flush=True)

        do('NoDesign', lambda: (H0, evaluate_network(H0)['R_hda']))
        do('DCBO', lambda: dcbo_baseline(H0, BUDGET))
        do('SA-Static', lambda: sa_baseline(H0, BUDGET, 'static', 300, seed))
        do('SA-Minimax', lambda: sa_baseline(H0, BUDGET, 'minimax', 250, seed))

        if seed in SEEDS_RL:
            def rl(mode):
                out = train_defender('BA', N, seed, BUDGET, RL_EPISODES, alpha=ALPHA,
                                      reward_mode=mode, verbose=False)
                return out[6], out[7]  # best_H, best_R
            do('RL-Static', lambda: rl('static'))
            do('RL-Minimax', lambda: rl('minimax'))

    f.close()
    print("DONE")


if __name__ == '__main__':
    run()
